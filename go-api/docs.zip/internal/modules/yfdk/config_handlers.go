package yfdk

import (
	"go-api/internal/response"

	"github.com/gin-gonic/gin"
)

func ConfigGet(c *gin.Context) {
	cfg, err := YFDK().GetConfig()
	if err != nil {
		response.ServerError(c, "获取配置失败")
		return
	}
	response.Success(c, cfg)
}

func ConfigSave(c *gin.Context) {
	var cfg YFDKConfig
	if err := c.ShouldBindJSON(&cfg); err != nil {
		response.BadRequest(c, "参数错误")
		return
	}
	if err := YFDK().SaveConfig(&cfg); err != nil {
		response.ServerError(c, "保存配置失败")
		return
	}
	response.SuccessMsg(c, "保存成功")
}
